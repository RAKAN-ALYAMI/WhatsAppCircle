<?php
include('config.php');

// جلب قائمة الموظفين
$sql = "SELECT * FROM employees";
$result = mysqli_query($conn, $sql);
$employees = [];

while ($row = mysqli_fetch_assoc($result)) {
    $employees[] = $row;
}

// جلب آخر موظف تم النقر عليه من قاعدة البيانات
$sql_last = "SELECT last_employee_id FROM employees WHERE id=1 LIMIT 1"; // جلب معرف آخر موظف
$result_last = mysqli_query($conn, $sql_last);
$last_employee = mysqli_fetch_assoc($result_last);

$response = [
    'employees' => $employees,
    'last_employee_id' => $last_employee['last_employee_id']
];

echo json_encode($response);
?>
