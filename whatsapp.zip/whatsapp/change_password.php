<?php
include('config.php');
include('auth.php');
include('security.php');

if (!check_system_integrity()) {
    display_block_message();
    exit();
}

$copyright_hash = verify_copyright_integrity();

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $error = "كلمة المرور الجديدة وتأكيدها غير متطابقين.";
    } else {
        $user_id = $_SESSION['user_id'];
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            if (password_verify($current_password, $user['password'])) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                $update_sql = "UPDATE users SET password = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("si", $hashed_password, $user_id);
                
                if ($update_stmt->execute()) {
                    $success = "تم تغيير كلمة المرور بنجاح.";
                } else {
                    $error = "حدث خطأ أثناء تحديث كلمة المرور.";
                }
            } else {
                $error = "كلمة المرور الحالية غير صحيحة.";
            }
        } else {
            $error = "لم يتم العثور على معلومات المستخدم.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تغيير كلمة المرور</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body {
            direction: rtl;
            text-align: right;
            background-color: #f1f1f1;
            font-family: 'Tajawal', sans-serif;
        }

        .navbar {
            background-color: #075e54;
        }
        
        .navbar .navbar-brand,
        .navbar .nav-link {
            color: #fff !important;
        }

        .navbar .nav-link:hover {
            color: #ddd !important;
        }

        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #128c7e;
        }

        .btn-custom {
            background-color: #25d366;
            color: white;
        }
        
        .btn-custom:hover {
            background-color: #128c7e;
        }

        .btn-logout {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #d9534f;
            color: white;
            font-weight: bold;
        }
        .btn-logout:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#"><i class="fas fa-cogs"></i> لوحة التحكم</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">
                        <i class="fas fa-home"></i> الرئيسية
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_employees.php">
                        <i class="fas fa-users"></i> مشاهدة الأرقام
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_employee.php">
                        <i class="fas fa-user-plus"></i> إضافة رقم
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                        <h2><i class="fas fa-key"></i> تغيير كلمة المرور</h2>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger">
                                <?php echo $error; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($success)): ?>
                            <div class="alert alert-success">
                                <?php echo $success; ?>
                            </div>
                        <?php endif; ?>
                        
                        <form method="post" action="">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">كلمة المرور الحالية</label>
                                <input type="password" class="form-control" id="current_password" name="current_password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">كلمة المرور الجديدة</label>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">تأكيد كلمة المرور الجديدة</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-custom">تغيير كلمة المرور</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <form action="logout.php" method="post">
        <button type="submit" class="btn btn-logout">تسجيل الخروج</button>
    </form>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <footer class="mt-4 text-center">
        <div class="container">
            <hr class="my-3">
            <p align="center" id="copyright_notice" class="text-center" style="color: #128c7e; font-size: 14px;" data-integrity="<?php echo $copyright_hash; ?>">
                RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com
            </p>
        </div>
    </footer>

    <script>
    (function() {
        function verifyIntegrity() {
            var notice = document.getElementById('copyright_notice');
            if (!notice || notice.innerText.trim() !== 'RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com') {
                window.location.href = 'blocked.php';
                
                fetch('update_clicks.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'security_violation=copyright_modified'
                });
            }
        }
        
        setInterval(verifyIntegrity, 5000);
        
        var observer = new MutationObserver(function(mutations) {
            verifyIntegrity();
        });
        
        observer.observe(document.body, { 
            childList: true,
            subtree: true,
            characterData: true
        });
    })();
    </script>
</body>
</html>
