<?php
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تم حظر الوصول</title>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            direction: rtl;
            text-align: center;
            background-color: #f1f1f1;
            font-family: 'Tajawal', Arial, sans-serif;
            padding: 20px;
            margin: 0;
        }
        .block-container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 500px;
            margin: 50px auto;
        }
        h1 {
            color: #d9534f;
            margin-bottom: 20px;
            font-weight: 700;
        }
        .contact-info {
            margin-top: 30px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .contact-button {
            display: inline-block;
            background-color: #25d366;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            margin-top: 20px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="block-container">
        <h1>تم حظر الوصول</h1>
        <p style="font-size:18px;">تم حظرك من استخدام السكربت بسبب تعديل حقوق الملكية</p>
        <p>لقد تم اكتشاف محاولة لتعديل أو إزالة حقوق الملكية الخاصة بالسكربت.</p>
        
        <div class="contact-info">
            <p><strong>لاستعادة السكربت يجب استرجاع الاسم الأصلي:</strong></p>
            <p style="color: #25d366; font-weight: bold; font-size: 16px;">RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com</p>
            <p>يرجى التأكد من إعادة النص الأصلي كما هو موضح أعلاه دون أي تغيير.</p>
        </div>
        
        <a href="https://t.me/r7000r" class="contact-button" target="_blank">
            تواصل معنا على Telegram
        </a>
    </div>
    
    <?php
    $log_file = __DIR__ . '/security.log';
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $log_entry = "[$timestamp] [$ip] [BLOCKED_PAGE_ACCESS] User accessed blocked page\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
    ?>
</body>
</html>
