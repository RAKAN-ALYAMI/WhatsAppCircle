<?php
include('config.php');
include 'auth.php'; 
$name = $_POST['name'];
$phone = $_POST['phone'];

$sql = "INSERT INTO employees (name, phone) VALUES ('$name', '$phone')";
if (mysqli_query($conn, $sql)) {
    header("Location: view_employees.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
