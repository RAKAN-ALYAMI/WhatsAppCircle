<?php
include('config.php');

$sql = "SELECT * FROM employees";
$result = mysqli_query($conn, $sql);
$employees = [];

while ($row = mysqli_fetch_assoc($result)) {
    $employees[] = $row;
}

$sql_last = "SELECT last_employee_id FROM last_employee LIMIT 1";
$result_last = mysqli_query($conn, $sql_last);
$last_employee = mysqli_fetch_assoc($result_last);

$currentEmployeeIndex = 0;

if (!empty($last_employee) && $last_employee['last_employee_id'] != 0) {
    foreach ($employees as $index => $employee) {
        if ($employee['id'] == $last_employee['last_employee_id']) {
            $currentEmployeeIndex = ($index + 1) % count($employees);
            break;
        }
    }
}

$currentEmployee = $employees[$currentEmployeeIndex];

$sql_update_last = "UPDATE last_employee SET last_employee_id = '" . $currentEmployee['id'] . "' WHERE id = 1";
mysqli_query($conn, $sql_update_last);

$sql_update_clicks = "UPDATE employees SET clicks = clicks + 1 WHERE id = '" . $currentEmployee['id'] . "'";
mysqli_query($conn, $sql_update_clicks);

header("Location: https://wa.me/" . $currentEmployee['phone']);
exit();
?>
