<?php
session_start();
include('config.php');
include('security.php');

if (!check_system_integrity()) {
    display_block_message();
    exit();
}

$copyright_hash = verify_copyright_integrity();

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!$conn) {
        die("فشل الاتصال بقاعدة البيانات: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['integrity_hash'] = $copyright_hash;

            header("Location: index.php");
            exit();
        } else {
            $error = "كلمة المرور غير صحيحة.";
        }
    } else {
        $error = "اسم المستخدم غير صحيح.";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap">
    <style>
        body {
            background-color: #eaeaea;
            font-family: 'Cairo', sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .login-container {
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 400px;
            width: 100%;
            margin: 50px auto;
        }
        .login-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-header img {
            width: 60px;
            height: 60px;
        }
        .login-header h2 {
            margin-top: 15px;
            font-weight: bold;
            color: #128c7e;
        }
        .btn-login {
            background-color: #25d366;
            color: white;
            font-weight: bold;
        }
        .btn-login:hover {
            background-color: #128c7e;
            color: white;
        }
        footer {
            margin-top: auto;
            padding: 20px 0;
            width: 100%;
            background-color: #f8f9fa;
        }
        .copyright {
            color: #128c7e;
            font-size: 14px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="whatsapp.png" alt="WhatsApp Logo">
            <h2>تسجيل الدخول</h2>
        </div>
        <form action="" method="post">
            <?php if (isset($error)) { echo "<div class='alert alert-danger text-center'>$error</div>"; } ?>
            <div class="mb-3">
                <label for="username" class="form-label">اسم المستخدم</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">كلمة المرور</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-login w-100">تسجيل الدخول</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <footer>
        <div class="container">
            <p align="center" id="copyright_notice" class="copyright">
                2023 RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com
            </p>
        </div>
    </footer>
</body>
</html>