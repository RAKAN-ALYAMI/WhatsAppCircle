<?php
// Security file for WhatsApp Borman script
// This file contains security checks and validations

if(!defined('SECURE_ACCESS')) {
    define('SECURE_ACCESS', true);
}

function generate_copyright_hash($content) {
    $salt = "wB0rm4n_2025"; 
    return hash('sha256', $content . $salt);
}

function verify_copyright_integrity() {
    $expected_copyright = '<p align="center">RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com</p>';
    $expected_hash = generate_copyright_hash($expected_copyright);
    
    if (!isset($_SESSION)) {
        session_start();
    }
    $_SESSION['integrity_check'] = $expected_hash;
    
    return $expected_hash;
}

function verify_system_integrity() {
    $files_to_check = [
        'config.php',
        'security.php',
        'index.php',
        'login.php'
    ];
    
    $checksum_file = __DIR__ . '/checksum.dat';
    $checksums = [];
    
    foreach ($files_to_check as $file) {
        $file_path = __DIR__ . '/' . $file;
        if (file_exists($file_path)) {
            $content = file_get_contents($file_path);
            $checksums[$file] = hash('sha256', $content);
        }
    }
    
    $encrypted_data = base64_encode(serialize($checksums));
    file_put_contents($checksum_file, $encrypted_data);
    
    return true;
}

function check_system_integrity() {
    $checksum_file = __DIR__ . '/checksum.dat';
    
    if (!file_exists($checksum_file)) {
        verify_system_integrity();
        return true;
    }
    
    $encrypted_data = file_get_contents($checksum_file);
    $stored_checksums = unserialize(base64_decode($encrypted_data));
    
    if (!is_array($stored_checksums)) {
        verify_system_integrity();
        return true;
    }
    
    foreach ($stored_checksums as $file => $stored_hash) {
        $file_path = __DIR__ . '/' . $file;
        if (file_exists($file_path)) {
            $current_content = file_get_contents($file_path);
            $current_hash = hash('sha256', $current_content);
            
            if ($current_hash !== $stored_hash) {
                return false;
            }
        } else {
            return false;
        }
    }
    
    return true;
}

function create_security_table($conn) {
    $sql = "CREATE TABLE IF NOT EXISTS security_violations (
        id INT(11) NOT NULL AUTO_INCREMENT,
        violation_type VARCHAR(50) NOT NULL,
        details TEXT,
        ip_address VARCHAR(45) NOT NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    )";
    return mysqli_query($conn, $sql);
}

function check_copyright_integrity() {
    if (!file_exists(__DIR__ . '/login.php')) {
        $log_file = __DIR__ . '/security.log';
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $log_entry = "[$timestamp] [$ip] [FILE_MISSING] login.php file is missing\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND);
        return false;
    }
    
    $login_content = file_get_contents(__DIR__ . '/login.php');
    
    $copyright_text = 'RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com';
    if (strpos($login_content, $copyright_text) === false) {
        $log_file = __DIR__ . '/security.log';
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        $log_entry = "[$timestamp] [$ip] [COPYRIGHT_MODIFIED] Copyright notice has been modified or removed\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND);
        header('Location: blocked.php');
        exit;
    }
    
    return true;
}

function verify_system_integrity_new() {
    if (!check_copyright_integrity()) {
        return false;
    }
    
    $core_files = ['index.php', 'login.php', 'config.php', 'license.php', 'security.php'];
    foreach ($core_files as $file) {
        if (!file_exists(__DIR__ . '/' . $file)) {
            $log_file = __DIR__ . '/security.log';
            $timestamp = date('Y-m-d H:i:s');
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
            $log_entry = "[$timestamp] [$ip] [FILE_MISSING] $file file is missing\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND);
            return false;
        }
    }
    
    return true;
}

function display_block_message() {
    echo '<!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>تم حظر الوصول</title>
        <!-- إضافة خط Google Tajawal -->
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
        <style>
            body {
                direction: rtl;
                text-align: center;
                background-color: #f1f1f1;
                font-family: "Tajawal", Arial, sans-serif;
                padding: 20px;
                margin: 0;
            }
            .block-container {
                background-color: white;
                border-radius: 10px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
                padding: 30px;
                max-width: 500px;
                margin: 50px auto;
            }
            h1 {
                color: #d9534f;
                margin-bottom: 20px;
                font-weight: 700;
            }
            .contact-info {
                margin-top: 30px;
                padding: 15px;
                background-color: #f8f9fa;
                border-radius: 5px;
            }
            .contact-button {
                display: inline-block;
                background-color: #25d366;
                color: white;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 5px;
                margin-top: 20px;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <div class="block-container">
            <h1>تم حظر الوصول</h1>
            <p style="font-size:18px;">تم حظرك من استخدام السكربت بسبب تعديل حقوق الملكية</p>
            <p>لقد تم اكتشاف محاولة لتعديل أو إزالة حقوق الملكية الخاصة بالسكربت.</p>
            
            <div class="contact-info">
                <p><strong>لاستعادة السكربت يجب استرجاع الاسم الأصلي:</strong></p>
                <p style="color: #25d366; font-weight: bold; font-size: 16px;">RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com</p>
                <p>يرجى التأكد من إعادة النص الأصلي كما هو موضح أعلاه دون أي تغيير.</p>
            </div>
            
            <a href="https://t.me/r7000r" class="contact-button" target="_blank">
                تواصل معنا على Telegram
            </a>
        </div>
    </body>
    </html>';
    exit();
}

function encrypt_data($data) {
    $key = "wB0rm4n_2025_secure_key";
    return base64_encode(openssl_encrypt($data, 'AES-256-CBC', $key, 0, substr($key, 0, 16)));
}

function decrypt_data($data) {
    $key = "wB0rm4n_2025_secure_key";
    return openssl_decrypt(base64_decode($data), 'AES-256-CBC', $key, 0, substr($key, 0, 16));
}

function log_security_violation($type, $details = '') {
    $log_file = __DIR__ . '/security.log';
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $log_entry = "[$timestamp] [$ip] [$type] $details\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
}

verify_copyright_integrity();
verify_system_integrity_new();
?>
