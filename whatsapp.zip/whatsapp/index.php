<?php
include('config.php');
include('auth.php');
include('security.php');

if (!check_system_integrity()) {
    display_block_message();
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body {
            direction: rtl;
            text-align: right;
            background-color: #f1f1f1;
            font-family: 'Tajawal', sans-serif;
        }

        .navbar {
            background-color: #075e54;
        }
        
        .navbar .navbar-brand,
        .navbar .nav-link {
            color: #fff !important;
        }

        .navbar .nav-link:hover {
            color: #ddd !important;
        }

        .table {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #128c7e;
        }

        .btn-custom {
            background-color: #25d366;
            color: white;
        }
        
        .btn-custom:hover {
            background-color: #128c7e;
        }

        .btn-logout {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #d9534f;
            color: white;
            font-weight: bold;
        }
        .btn-logout:hover {
            background-color: #c9302c;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#"><i class="fas fa-cogs"></i> لوحة التحكم</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="view_employees.php">
                        <i class="fas fa-users"></i> مشاهدة الأرقام
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="add_employee.php">
                        <i class="fas fa-user-plus"></i> إضافة رقم
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="change_password.php">
                        <i class="fas fa-key"></i> تغيير الرقم السري
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h1><i class="fas fa-address-book"></i> الأرقام</h1>
        
        <div class="alert alert-warning mb-4" role="alert">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>تنبيه:</strong> يجب إضافة رمز الدولة عند إدخال رقم الجوال (مثال: +966)
        </div>
        
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">اسم الموظف</th>
                    <th scope="col">رقم الجوال</th>
                    <th scope="col">عدد النقرات</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM employees";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<th scope='row'>" . $row['id'] . "</th>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['phone'] . "</td>";
                        echo "<td>" . $row['clicks'] . "</td>";
                        echo "</tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <form action="logout.php" method="post">
        <button type="submit" class="btn btn-logout">تسجيل الخروج</button>
    </form>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <footer class="mt-4 text-center">
        <div class="container">
            <hr class="my-3">
            <p align="center" id="copyright_notice" class="text-center" style="color: #128c7e; font-size: 14px;" data-integrity="<?php echo $copyright_hash; ?>">
                RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com
            </p>
        </div>
    </footer>

    <script>
    (function() {
        function verifyIntegrity() {
            var notice = document.getElementById('copyright_notice');
            if (!notice || notice.innerText.trim() !== 'RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com') {
                window.location.href = 'blocked.php';
                
                fetch('update_clicks.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'security_violation=copyright_modified'
                });
            }
        }
        
        setInterval(verifyIntegrity, 5000);
        
        var observer = new MutationObserver(function(mutations) {
            verifyIntegrity();
        });
        
        observer.observe(document.body, { 
            childList: true,
            subtree: true,
            characterData: true
        });
    })();
    </script>
</body>
</html>