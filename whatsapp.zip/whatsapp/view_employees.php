<?php
include('config.php');
include 'auth.php'; 
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عرض الموظفين</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            direction: rtl;
            text-align: right;
            background-color: #f1f1f1;
            font-family: 'Tajawal', sans-serif;
        }

        .navbar {
            background-color: #075e54;
        }
        
        .navbar .navbar-brand,
        .navbar .nav-link {
            color: #fff !important;
        }

        .table {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #128c7e;
        }

        .btn-custom {
            background-color: #25d366;
            color: white;
        }
        
        .btn-custom:hover {
            background-color: #128c7e;
        }

        .btn-action {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#">عرض الموظفين</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">العودة إلى لوحة التحكم</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5">
        <h1>الموظفين</h1>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>#</th>
                    <th>اسم الموظف</th>
                    <th>رقم الجوال</th>
                    <th>عدد النقرات</th>
                    <th>إجراء</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM employees";
                $result = mysqli_query($conn, $sql);
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<th scope='row'>" . $row['id'] . "</th>";
                        echo "<td>" . $row['name'] . "</td>";
                        echo "<td>" . $row['phone'] . "</td>";
                        echo "<td>" . $row['clicks'] . "</td>";
                        echo "<td><a href='delete_employee.php?id=" . $row['id'] . "' class='btn btn-danger'>حذف</a></td>";
                        echo "</tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div>

    <div class="container btn-action">
        <a href="add_employee.php" class="btn btn-success">إضافة رقم</a>
        <a href="index.php" class="btn btn-primary">الرجوع إلى الصفحة الرئيسية</a>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
