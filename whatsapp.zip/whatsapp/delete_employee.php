<?php
include('config.php');
include 'auth.php'; 
$id = $_GET['id'];

$sql = "DELETE FROM employees WHERE id='$id'";
if (mysqli_query($conn, $sql)) {
    header("Location: view_employees.php");
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
