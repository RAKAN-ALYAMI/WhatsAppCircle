<?php
include('config.php');
include('security.php'); 

if (isset($_POST['security_violation'])) {
    $violation_type = $_POST['security_violation'];
    log_security_violation('CLIENT_SIDE_VIOLATION', $violation_type);
    
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $timestamp = date('Y-m-d H:i:s');
    $sql = "INSERT INTO security_violations (violation_type, ip_address, timestamp) VALUES ('$violation_type', '$ip', '$timestamp')";
    
    if (!mysqli_query($conn, $sql)) {
        $create_table = "CREATE TABLE IF NOT EXISTS security_violations (
            id INT AUTO_INCREMENT PRIMARY KEY,
            violation_type VARCHAR(100) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            timestamp DATETIME NOT NULL,
            details TEXT
        )";
        mysqli_query($conn, $create_table);
        
        mysqli_query($conn, $sql);
    }
    
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Security violation detected']);
    exit();
}

if (isset($_POST['phone'])) {
    $phone = $_POST['phone'];

    $sql_update_clicks = "UPDATE employees SET clicks = clicks + 1 WHERE phone='$phone'";
    mysqli_query($conn, $sql_update_clicks);

    $sql_get_employee_id = "SELECT id FROM employees WHERE phone='$phone' LIMIT 1";
    $result = mysqli_query($conn, $sql_get_employee_id);
    $employee = mysqli_fetch_assoc($result);
    $employee_id = $employee['id'];

    $sql_update_last = "UPDATE employees SET last_employee_id='$employee_id' WHERE id=1"; 
    mysqli_query($conn, $sql_update_last);
}
?>
