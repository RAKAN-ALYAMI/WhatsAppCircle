<?php
session_start();
include('config.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$status_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['unblock'])) {
    $checksum_file = __DIR__ . '/checksum.dat';
    if (file_exists($checksum_file)) {
        unlink($checksum_file);
        $status_message = 'تم حذف ملف التحقق بنجاح.';
    }
    
    $sql = "TRUNCATE TABLE security_violations";
    if (mysqli_query($conn, $sql)) {
        $status_message .= ' تم حذف سجلات الانتهاكات بنجاح.';
    } else {
        $status_message .= ' لم يتم العثور على سجلات انتهاكات.';
    }
    
    $log_file = __DIR__ . '/security.log';
    if (file_exists($log_file)) {
        unlink($log_file);
        $status_message .= ' تم حذف ملف السجل بنجاح.';
    }
    
    if (function_exists('verify_system_integrity')) {
        include('security.php');
        verify_system_integrity();
        $status_message .= ' تم إعادة إنشاء ملف التحقق بنجاح.';
    }
}

$violations = [];
$sql = "SHOW TABLES LIKE 'security_violations'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $sql = "SELECT * FROM security_violations ORDER BY timestamp DESC LIMIT 50";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $violations[] = $row;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الحظر</title>
    <!-- إضافة Bootstrap عبر CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- إضافة خط Google Tajawal -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- إضافة مكتبة Font Awesome عبر CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <style>
        body {
            direction: rtl;
            text-align: right;
            background-color: #f1f1f1;
            font-family: 'Tajawal', sans-serif;
        }
        
        .navbar {
            background-color: #075e54;
        }
        
        .navbar .navbar-brand,
        .navbar .nav-link {
            color: #fff !important;
        }
        
        .navbar .nav-link:hover {
            color: #ddd !important;
        }
        
        .card {
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: #128c7e;
            color: white;
            font-weight: bold;
        }
        
        .btn-primary {
            background-color: #25d366;
            border-color: #25d366;
        }
        
        .btn-primary:hover {
            background-color: #128c7e;
            border-color: #128c7e;
        }
        
        .btn-danger {
            background-color: #d9534f;
            border-color: #d9534f;
        }
        
        .table {
            background-color: white;
        }
        
        .alert-success {
            background-color: #d4edda;
            border-color: #c3e6cb;
            color: #155724;
        }
    </style>
</head>
<body>
    <!-- قائمة التنقل -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-shield-alt"></i> إدارة الحظر</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home"></i> الرئيسية
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (!empty($status_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $status_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-unlock"></i> إزالة الحظر
                    </div>
                    <div class="card-body">
                        <p>استخدم هذا الخيار لإزالة الحظر عن المستخدمين الذين تم حظرهم بسبب تعديل حقوق الملكية.</p>
                        <p>سيؤدي هذا إلى:</p>
                        <ul>
                            <li>حذف ملف التحقق (checksum.dat)</li>
                            <li>حذف سجلات الانتهاكات من قاعدة البيانات</li>
                            <li>حذف ملف السجل (security.log)</li>
                            <li>إعادة إنشاء ملف التحقق بالقيم الصحيحة</li>
                        </ul>
                        <form method="post" onsubmit="return confirm('هل أنت متأكد من رغبتك في إزالة الحظر عن جميع المستخدمين؟');">
                            <button type="submit" name="unblock" class="btn btn-primary">
                                <i class="fas fa-unlock-alt"></i> إزالة الحظر
                            </button>
                        </form>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-info-circle"></i> تعليمات إزالة الحظر يدويًا
                    </div>
                    <div class="card-body">
                        <p>إذا كنت ترغب في إزالة الحظر يدويًا، اتبع الخطوات التالية:</p>
                        <ol>
                            <li>احذف ملف <code>checksum.dat</code> من مجلد المشروع</li>
                            <li>تأكد من أن نص حقوق الملكية في ملف <code>index.php</code> هو:
                                <pre class="bg-light p-2 mt-2">RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com</pre>
                            </li>
                            <li>قم بتسجيل الخروج وإعادة تسجيل الدخول</li>
                        </ol>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-exclamation-triangle"></i> سجل الانتهاكات
                    </div>
                    <div class="card-body">
                        <?php if (empty($violations)): ?>
                            <p class="text-center">لا توجد انتهاكات مسجلة.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>نوع الانتهاك</th>
                                            <th>عنوان IP</th>
                                            <th>التاريخ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($violations as $index => $violation): ?>
                                            <tr>
                                                <td><?php echo $index + 1; ?></td>
                                                <td><?php echo htmlspecialchars($violation['violation_type']); ?></td>
                                                <td><?php echo htmlspecialchars($violation['ip_address']); ?></td>
                                                <td><?php echo htmlspecialchars($violation['timestamp']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- إضافة jQuery و Bootstrap JavaScript عبر CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <footer class="mt-5">
        <p align="center" id="copyright_notice">RAKAN ALYAMI - Telegram: @r7000r - email: rakan7777@gmail.com</p>
    </footer>
</body>
</html>
